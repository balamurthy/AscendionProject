package sanityTests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utilities.Helper;

public class registerStudentTest extends Helper{
    static WebDriver driver;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		driver=Helper.launchBrowser("chrome");
		
		driver.get("https://demoqa.com/automation-practice-form");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,800)");
		
		driver.findElement(By.id("firstName")).sendKeys("Harry");
		driver.findElement(By.id("lastName")).sendKeys("Potter");
		driver.findElement(By.id("userEmail")).sendKeys("harry@abc.com");
		//radio button
		driver.findElement(By.cssSelector("label[for='gender-radio-2']")).click();
		driver.findElement(By.id("userNumber")).sendKeys("0123456789");
		
		//Scroll down
		js.executeScript("window.scrollBy(0,800)");
		
		//Select DOB field then select date of month dropdown and assign to variable then select month by index
        driver.findElement(By.id("dateOfBirthInput")).click();
        Select MonthSelect = new Select(driver.findElement(By.className("react-datepicker__month-select")));
        MonthSelect.selectByIndex(0);

        
        //Select year and assign to variable, then select year by index
        Select YearSelect = new Select(driver.findElement(By.className("react-datepicker__year-select")));
        YearSelect.selectByValue("1999");

        
        //Select the specific day you want by classname
        driver.findElement(By.className("react-datepicker__day--028")).click();
	    
        WebElement subj=driver.findElement(By.id("subjectsInput"));
        subj.sendKeys("English");
        subj.sendKeys(Keys.ARROW_DOWN);
        subj.sendKeys(Keys.ENTER);
        
        //checkbox
        driver.findElement(By.cssSelector("label[for='hobbies-checkbox-2']")).click();
		        
        driver.findElement(By.id("uploadPicture")).sendKeys("d:\\blaptop\\ascendion\\asc.html");
		driver.findElement(By.id("currentAddress")).sendKeys("No 10 downing street " + Keys.TAB);
		
		//select box for state
		WebElement state = driver.findElement(By.id("react-select-3-input"));
		state.sendKeys(Keys.chord(Keys.DOWN, Keys.ENTER,Keys.TAB));
		
		WebElement city = driver.findElement(By.id("react-select-4-input"));
		city.sendKeys(Keys.chord(Keys.DOWN, Keys.ENTER));
		
		driver.findElement(By.id("submit")).click(); 

		try {
			driver.findElement(By.xpath("//*[contains(text(),\"Thanks\")]"));
			System.out.println("Registration Successful!");
		}
		catch (NoSuchElementException ne)
		{
			System.out.println("Registration not done");
		}
		
	}
}

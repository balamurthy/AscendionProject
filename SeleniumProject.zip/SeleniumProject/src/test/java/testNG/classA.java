package testNG;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import Pages.landingPage;
import Pages.loginPage;
import utilities.Helper;

public class classA {
	ExtentReports extentreports;
	ExtentTest test;
	static WebDriver driver;
	loginPage lp;
	landingPage wp;

	@DataProvider(name = "login")
	public Object[][] createData1() {
		return new Object[][] {
			{ "tomsmith", "SuperSecretPassword!" },
			{ "Abcd", "efgh"},
		};
	}


		
	@BeforeClass
	public void beforeClassClassA()
	{
		driver = Helper.launchBrowser("ff");
		driver.get("https://the-internet.herokuapp.com/login");
		lp = new loginPage(driver);
		wp = new landingPage(driver);

		System.out.println("Before class in classA");

		extentreports = new ExtentReports("d://blaptop//ascendion//extentreports//extent.html", true);

		test = extentreports.startTest("ClassA");
	}

	@Test(dataProvider="login",groups= {"SmokeTest"})

	public void login(String u,String p) {
		boolean status;
		lp.login(u, p);
		
		status = wp.isLogoutBtnPresent();

		if (status==true)
		{
			test.log(LogStatus.PASS, "Login passed " + u + " " + p);
		}
		else
		{
			test.log(LogStatus.FAIL, "Login Failed " + u + " "+ p);
		}
		System.out.println("Login running "+ u + p);

		Assert.assertEquals(status, true);

		
	}

	/*
	@AfterClass
	public void afterClassClassA()
	{
		System.out.println("After class in classA");
		extentreports.endTest(test);
		extentreports.flush();
	}	
*/
}

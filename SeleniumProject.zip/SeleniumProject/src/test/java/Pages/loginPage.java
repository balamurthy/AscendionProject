package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.Helper;

public class loginPage {
	
	//constructor
	private WebDriver driver;
	
	public loginPage(WebDriver driver)
	{
		this.driver=driver;
		
	}

	//elements
	By username = By.name("username");
	By password = By.name("password");
	By loginBtn = By.cssSelector("#login > button");
	
	//getter and setter methods
	
	public void setUsername(String u)
	{
		driver.findElement(username).sendKeys(u);
	}
	
	public void setPassword(String u)
	{
		driver.findElement(password).sendKeys(u);
	}
	
	public void clickLoginButton()
	{
		driver.findElement (loginBtn).click();
	}
	
	public boolean isPasswordMasked()
	{
	     boolean result;
	     String type = driver.findElement(password).getAttribute("type");
	     if (type.equals("password"))
	     {
	    	 result = true;
	     }
	    	else {
	    	 result = false;
	    	}
	     
	     return result; 
	      
	}
	
	public String chkLocationOfUsername() {
		
		System.out.println(driver.findElement(username).getLocation());
		return driver.findElement(username).getLocation().toString();
		
	}
	
	
	public void login(String u,String p)
	{
	boolean status;
	
	driver.findElement(username).sendKeys(u);
	
	driver.findElement(password).sendKeys(p);
	
	
	
	//Validation step
		driver.findElement(loginBtn).click();
		
	
	}

	public Point getPositionOfUsername()
	{
		return driver.findElement(username).getLocation();
		
		
	}
}

package testNG;

import org.testng.annotations.Test;

public class groupExample {
  @Test(groups= {"SmokeTest"})
  public void first() {
	  
	  System.out.println("In first smoke test");
  }
  
  @Test(groups= {"SanityTest"})
  public void Second() {
	  
	  System.out.println("In Sanity test");
  }
  
  
}

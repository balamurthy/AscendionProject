package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.advantageOnlineHomePage;

public class AdvOnlineHomePageTestCases {
	
 static WebDriver driver;
 static advantageOnlineHomePage advhome;
 
 @BeforeClass
 public void beforeclass() {
	 driver=new ChromeDriver();
	 driver.get("https://advantageonlineshopping.com/#/");
	 advhome = new advantageOnlineHomePage(driver);
	  
 
 }
  @Test
  public void isSearchboxThere() {

	 boolean status;
	 
	 status = advhome.isSearchboxAvailable();
	 
	 Assert.assertEquals(status, true);
  }
  
  @Test 
  public void isLogoPresentInTheSamePlace()
  {
	  boolean status;
	  
	  status = advhome.isLogoInTheSamePlace();
	  
	  Assert.assertEquals(status, true);
	  
  }
  
}

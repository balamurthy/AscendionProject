package sanityTests;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import utilities.Helper;

public class Login_herokuapp extends Helper {
	static WebDriver driver;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		driver = Helper.launchBrowser("ff");
		
		driver.get("https://the-internet.herokuapp.com/login");
		
		boolean result;
		
		result = login("tom1","super2");
		System.out.println(result);
		
		result = login("tomsmith","SuperSecretPassword!");
		System.out.println(result);
		
		
		
	}	
		public static boolean login(String username,String password)
		{
		boolean status;
		
		driver.findElement(By.id("username")).sendKeys(username);
		
		driver.findElement(By.id("password")).sendKeys(password);
		
		//Validation step
		try {
			driver.findElement(By.cssSelector("#login > button")).click();
		
			//check for footer after logging in
			driver.findElement(By.partialLinkText("out")).click();
			status=true;
			System.out.println("Login success for " + username + " & "+ password);
			
		}
		catch (NoSuchElementException e)
		{
		
			System.out.println("Login failed for " + username + " & "+ password);
		
		//After login, check if logout button is there 
		//take a screenshot 
		//highlight the element 
			WebElement message = driver.findElement(By.id("flash"));
			Helper.highlightElement(driver, message);
			
			Helper.captureScreenShot(driver, username+"_"+ password);
			
			status=false;
		}
		//driver.close();
		return status;
		}
		
	}



package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;

import utilities.Helper;

public class samplePage {
	
	//constructor
	private WebDriver driver;
	
	public samplePage(WebDriver driver)
	{
		this.driver=driver;
		
	}

	//elements
	By logo = By.xpath("/html/body/table/tbody/tr[1]/td[2]/img");
	
	
	//getter and setter methods
	
	
	public boolean isLogoInTheSamePlace()
	{
		boolean status;
		try {
			
			driver.findElement(logo);
			status=true;
		}
		catch (NoSuchElementException ne)
		{
			status=false;
		}
		return status;
	}
	
	
}

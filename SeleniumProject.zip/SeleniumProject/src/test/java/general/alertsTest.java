package general;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilities.Helper;

public class alertsTest extends Helper{
	static WebDriver driver;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		driver=Helper.launchBrowser("ff");
		
		driver.get("https://demoqa.com/alerts");
		
		//first alert 
		//driver.findElement(By.id("alertButton")).click();
		//driver.switchTo().alert().accept();
		
		//confirm
		//driver.findElement(By.id("confirmButton")).click();
		//driver.switchTo().alert().dismiss();
		
		driver.findElement(By.id("promtButton")).click();
		String txt = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		System.out.println(txt);		
	}

}

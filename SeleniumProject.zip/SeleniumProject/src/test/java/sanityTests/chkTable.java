package sanityTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilities.Helper;

public class chkTable extends Helper{
	static WebDriver driver;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		driver = Helper.launchBrowser("edge");
		
		driver.get("file:///D:/BLaptop/Ascendion/asc.html");
		
		String label = driver.findElement(By.xpath("//table[@id=\"login\"]/tbody/tr/td")).getText();
		System.out.println(label);
		
		
	}

}

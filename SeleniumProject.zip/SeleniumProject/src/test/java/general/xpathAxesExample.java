package general;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import utilities.Helper;

public class xpathAxesExample extends Helper {
	static WebDriver driver;
    static final String COMPANY = "Angel One";
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		driver=Helper.launchBrowser("ff");
		//file:///D:/wrapper.html
		
		WebElement txt_email,lnk_logout;
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		// open the browser with the url
		driver.get("https://money.rediff.com/gainers/bse/daily/groupa");
		
	WebElement getCurrentPrice,getPercentage;  
		String path1= "//a[contains(text(),'"+ COMPANY +"')]/parent::td/following-sibling::td[3]";
		
		getCurrentPrice = driver.findElement(By.xpath(path1));
		
		
		System.out.println(getCurrentPrice.getText());
		
		//following-sibling
		
		getPercentage = driver.findElement(By.xpath("//a[contains(text(),'"+ COMPANY + "')]/parent::td/following-sibling::td[3]/following-sibling::td"));
		System.out.println(getPercentage.getText());
		
		
		
		
	}

}
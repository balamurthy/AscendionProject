package testNG;

import org.testng.annotations.Test;


public class classB {
  @Test(dependsOnMethods= {"B"})
  public void classBMethodA()
  {
  
  System.out.println("Class B method A running");
  }
  
  @Test
  public void B()
  {
	  System.out.println("Class B method B running");
  }
}

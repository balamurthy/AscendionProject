package testCases;

import org.openqa.selenium.WebDriver;

import Pages.landingPage;
import Pages.loginPage;
import general.LandingPage;
import utilities.ExcelApiTest;
import utilities.Helper;

public class loginPageTestCases {
	static WebDriver driver;

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ExcelApiTest xl=new ExcelApiTest("d://blaptop//ascendion//userdata.xlsx");
		driver = Helper.launchBrowser("ff");
		driver.get("https://the-internet.herokuapp.com/login");

		loginPage lp = new loginPage(driver);


		//Check position of username Test step
		if (lp.chkLocationOfUsername().equals("(198, 234)"))
		{	
			System.out.println("Username is in the same position");
		}	
		else
		{
			System.out.println("Username position has changed.");
		}

		//check if password is masked

		boolean masked = lp.isPasswordMasked();
		if (masked == true) {
			System.out.println("Password is masked");
		}
		else
		{
			System.out.println("Password is NOT masked");

		}
		int rows = xl.getRowCount("Sheet1");
		int cols = xl.getColumnCount("Sheet1");
		String username="";
		String password = "";
		for (int r=0; r < rows ;r++) {
			for (int c = 0;c < cols; c++) {
				
				username = xl.getCellData("Sheet1", 0, r);
				password = xl.getCellData("Sheet1", 1, r);
				//Check if login is successful
				
							}
			
		
		lp.login(username, password);
		landingPage  wp = new landingPage(driver);


		boolean result = wp.isLogoutBtnPresent();

		if (result == true) {
			System.out.println("Login successful for Username:"+ username+ " Password: " + password);
		}
		else
		{
			System.out.println("Login failed for Username:" + username + " Password: " + password);
		}

		System.out.println(wp.getMessage());

		}

	}


}





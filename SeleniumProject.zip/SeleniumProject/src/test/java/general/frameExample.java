

package general;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;

public class frameExample{

    
    public static void main(String[] args) {
    	
    	 WebDriver driver = new ChromeDriver();
         driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
        
         // Navigate to Url
         driver.get("https://www.selenium.dev/selenium/web/iframes.html");
        
         //switch To IFrame using Web Element
         WebElement iframe = driver.findElement(By.id("iframe1"));
         //Switch to the frame
         driver.switchTo().frame(iframe);
         //Now we can type text into email field
         WebElement emailE= driver.findElement(By.id("email"));
         emailE.sendKeys("admin@selenium.dev");
         emailE.clear();
         driver.switchTo().defaultContent();
         
         System.out.println(driver.findElement(By.xpath("//h1")).getText());
         
         
         //switch To IFrame using name or id
         driver.findElement(By.name("iframe1-name"));
         //Switch to the frame
         driver.switchTo().frame(iframe);
         
         WebElement email=driver.findElement(By.id("email"));
         //Now we can type text into email field
         email.sendKeys("admin@selenium.dev");
         email.clear();
         driver.switchTo().defaultContent();
     
         
         //switch To IFrame using index
         driver.switchTo().frame(0);
         
         //leave frame
         driver.switchTo().defaultContent();
         
         //quit the browser
         driver.quit();
    }

}
package testNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.advantageOnlineHomePage;
import Pages.samplePage;

public class testSample {
	
	 static WebDriver driver;
	 static samplePage sample;
	 
	 @BeforeClass
	 public void beforeclass() {
		 driver=new ChromeDriver();
		 driver.get("d://sample.html");
		 sample = new samplePage(driver);
		  
	 
	 }

  @Test
  public void chklogopos() {
	  
	  boolean status;
	  
	  status = sample.isLogoInTheSamePlace();
	  
	  Assert.assertEquals(status, true);
  }
}

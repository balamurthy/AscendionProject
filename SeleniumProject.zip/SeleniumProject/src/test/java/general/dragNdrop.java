package general;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utilities.Helper;

public class dragNdrop extends Helper{
	static WebDriver driver;
	public static void main(String[] args)
	{
	driver=Helper.launchBrowser("chrome");
	driver.get("https://www.selenium.dev/selenium/web/mouse_interaction.html");
	
	        WebElement draggable = driver.findElement(By.id("draggable"));
	        WebElement droppable = driver.findElement(By.id("droppable"));
	        new Actions(driver)
	                .dragAndDrop(draggable, droppable)
	                .perform();
	
	       if (driver.findElement(By.id("drop-status")).getText().equals("dropped"))
	       {
	    	   System.out.println("Dropped");
	       }
}

}
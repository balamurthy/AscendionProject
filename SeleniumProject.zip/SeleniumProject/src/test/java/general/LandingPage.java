package general;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilities.Helper;

public class LandingPage {
	
	//constructor
	static WebDriver driver;
	public LandingPage(WebDriver driver)
	{
		this.driver=driver;
		
	}

	//elements
	By message = By.id("flash");
	By logoutBtn = By.partialLinkText("Logout");
	
	//getter and setter methods
	
	public String getMessage()
	{
		return driver.findElement(message).getText();
	
	}
	
	public boolean isLogoutBtnPresent()
	{
		boolean status;
		try
		{
			driver.findElement(logoutBtn);
			status=true;
			
		}	
		catch(NoSuchElementException ne)
		{
			status=false;
		}
		return status;
		
	}
	
	public void clickLogoutButton()
	{
		driver.findElement (logoutBtn).click();
	}
	
	
}

package general;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import utilities.Helper;

public class accessibilityTest extends Helper{
	static WebDriver driver;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		    driver=Helper.launchBrowser("ff");  
	        driver.get("file:///D:/BLaptop/Ascendion/asc.html");
		
		List <WebElement> we = driver.findElements(By.cssSelector("table td:not([title])"));		
		
		System.out.println(we.size());
		StringBuilder sb=new StringBuilder();
		sb.append("The elements having no title attribute (tooltip text) are:");
		
		for(WebElement l:we)
		{
			
				
				sb.append(l.getAttribute("outerHTML") + " ");
			 
					
			}
			
		System.out.println(sb);
			
		}
		
			
				
	}
	
